create function sync_user_details() returns trigger
    language plpgsql
as
$$
BEGIN
    -- 1. If the change happened in the TEACHER table, update the USERS table
    IF (TG_TABLE_NAME = 'teacher') THEN
        UPDATE users 
        SET full_name = NEW.full_name 
        WHERE email = NEW.email 
        AND full_name IS DISTINCT FROM NEW.full_name;
        
    -- 2. If the change happened in the STUDENT table, update the USERS table
    ELSIF (TG_TABLE_NAME = 'student') THEN
        UPDATE users 
        SET full_name = NEW.full_name 
        WHERE email = NEW.email 
        AND full_name IS DISTINCT FROM NEW.full_name;

    -- 3. If the change happened in the USERS table, find if they are teacher/student and update them
    ELSIF (TG_TABLE_NAME = 'users') THEN
        -- Sync to Teacher table if role matches
        IF (NEW.role = 'teacher') THEN
            UPDATE teacher 
            SET full_name = NEW.full_name 
            WHERE email = NEW.email 
            AND full_name IS DISTINCT FROM NEW.full_name;
        
        -- Sync to Student table if role matches
        ELSIF (NEW.role = 'student') THEN
            UPDATE student 
            SET full_name = NEW.full_name 
            WHERE email = NEW.email 
            AND full_name IS DISTINCT FROM NEW.full_name;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$$;

alter function sync_user_details() owner to postgres;

grant execute on function sync_user_details() to anon;

grant execute on function sync_user_details() to authenticated;

grant execute on function sync_user_details() to service_role;

